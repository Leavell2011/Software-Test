import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("12345", "James", "Sun", "1234567890", "123 Webb St");
        contactService.addContact(contact);

        Contact retrievedContact = contactService.getContact("12345");
        Assertions.assertEquals(contact, retrievedContact);

        // Additional assertions for the retrieved contact
        Assertions.assertEquals("12345", retrievedContact.getContactID());
        Assertions.assertEquals("James", retrievedContact.getFirstName());
        Assertions.assertEquals("Sun", retrievedContact.getLastName());
        Assertions.assertEquals("1234567890", retrievedContact.getPhone());
        Assertions.assertEquals("123 Webb St", retrievedContact.getAddress());
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("12345", "James", "Sun", "1234567890", "123 Webb St");
        contactService.addContact(contact);

        contactService.deleteContact("12345");

        Contact retrievedContact = contactService.getContact("12345");
        Assertions.assertNull(retrievedContact);
    }

    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("12345", "James", "Sun", "1234567890", "123 Webb St");
        contactService.addContact(contact);

        contactService.updateFirstName("12345", "Jane");

        Contact retrievedContact = contactService.getContact("12345");
        Assertions.assertEquals("Jane", retrievedContact.getFirstName());
    }

    // Add more tests for other update methods and edge cases
}
