import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactTest {
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("12345", "James", "Sun", "1234567890", "123 Webb St");
        Assertions.assertEquals("12345", contact.getContactID());
        Assertions.assertEquals("James", contact.getFirstName());
        Assertions.assertEquals("Sun", contact.getLastName());
        Assertions.assertEquals("1234567890", contact.getPhone());
        Assertions.assertEquals("123 Webb St", contact.getAddress());
    }

    // Add more tests for other methods and edge cases
}
